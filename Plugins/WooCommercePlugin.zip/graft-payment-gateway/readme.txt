The GRAFT WooCommerce Plugin Installation Guide
(Manual Installation instructions)
The GRAFT WooCommerce Plugin - allows WooCommerce stores to accept CryptoCurrency (Bitcoin, Ethereum and GRFT) payments.

Prerequisites:
Your online store based on WordPress (you have to do it yourself)
SMTP Server credentials (you have to do it yourself)
GRAFT Node instance (you have to do it with:
https://github.com/graft-project/graft-ng/wiki/Alpha-RTA-Testnet-Install-&-Usage-Instruction)
You don't need this step if you installed  it  for Exchange Broker
Exchange Broker (you have to do it with:
 https://github.com/graft-project/exchange-broker/blob/master/README.md)
Payment Gateway (you have to do it with: https://github.com/graft-project/payment-gateway/blob/master/README.md )



Installation
Install plugin:
1.1. Plugin for WooCommerce is in  directory  src/payment-gateway/PaymentGateway/Plugins/WooCommercePlugin.zip 
1.2. Download plugin - you can download plugin two ways

Via FTP 
1.2.1. Upload the WooCommercePlugin.zip  to the /wp-content/plugins/ directory located on your server.

Via Wordpress Dashboard

1.2.2.  Log into your WordPress dashboard
1.2.3. Go to  WordPress Dashboard.
1.2.4. Enter menu  Plugins -> Add New
1.2.5. Navigate ADD Plugins -> Add Plugin.
1.3. Choose the WooCommercePlugin.zip file and press button �Install Now�.

2. Activate plugin
2.1. Press button �Activate Plagin�.
2.2. Plugin is activated if you can see it on the screen

3. Configure API key and Secret Key:
3.1. Go to Payment Gateway terminal and Login as Merchant.
3.2. Create a new online story in Payment Gateway. 
3.3. Create new API key.
3.3.  Press button �Detail� on the record of new API Key and save API key and Secret Key.

4. Configure setting:
4.1 Go to menu WooCommerce > Settings.
4.2. Press bookmark �Payments�.
4.3. Select row GRAFT and press button Manage.
4.3. Enter API credentials:
API Key - API key from PaymentGateway
API Secret  - API Secret from PaymentGateway.

For saving information  enable the plugin and press button �Save changes�.

4.4. Go to menu WooCommerce > Settings again, press bookmark �Payment�

Plugin is installed successfully if you can see on the screen record and on the button Manage you can see filled API credentials.
